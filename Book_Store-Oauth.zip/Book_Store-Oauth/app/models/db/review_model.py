from pydantic import Field
from app.models.db.base_model import create_update

class Review(create_update):
    book_id: str = Field(...)
    user_id: str = Field(...)
    rating: float = Field(...)  
    title : str = Field(...)
    comment: str = Field(...)