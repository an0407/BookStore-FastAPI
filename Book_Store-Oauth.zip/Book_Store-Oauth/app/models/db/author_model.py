from pydantic import Field
from app.models.db.base_model import name_schema
from typing import Optional

class Author(name_schema):
    biography : str = Field(...)
    birth_date : str = Field(...)
    death_date : Optional[str] = None
    country : str = Field(...)
    book_count : int = Field(0)