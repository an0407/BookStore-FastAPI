from pydantic import BaseModel, Field
from typing import Optional, List
from app.models.pydantic.base_model import create, update, Books

class AuthorCreate(BaseModel):
    name : str = Field(..., examples=['John', 'Jake'])
    biography : str = Field(..., examples=['This author wrote fiction books..'])
    birth_date : str = Field(..., examples=['01-09-1976', '12-07-1999'])
    country : str = Field(..., examples=['United States', 'United Kingdom'])

class AuthorCreateResponse(create):
    name : str = Field(...)
    biography : str = Field(...)
    birth_date : str = Field(...)
    death_date : Optional[str] = None
    country : str = Field(...)
    book_count : int = Field(0)

class AuthorUpdate(BaseModel):
    name : str = Field(..., examples=['John', 'Jake'])
    biography : str = Field(..., examples=['This author wrote fiction books..'])
    birth_date : str = Field(..., examples=['01-09-1976', '12-07-1999'])
    death_date : Optional[str] = Field("",examples=['01-09-1976', '12-07-1999'])
    country : str = Field(..., examples=['United States', 'United Kingdom'])

class AuthorUpdateResponse(update):
    name : str = Field(...)
    biography : str = Field(...)
    birth_date : str = Field(...)
    death_date : Optional[str] = None
    country : str = Field(...)
    book_count : int

class GetAuthorIdResponse(create):
    name : str = Field(...)
    biography : str = Field(...)
    birth_date : str = Field(...)
    death_date : Optional[str] = None
    country : str = Field(...)
    books : List[Books]

class GetAuthorsResponse(BaseModel):
    count : int
    next : Optional[str] = None
    previous : Optional[str] = None
    results: List[AuthorCreateResponse]