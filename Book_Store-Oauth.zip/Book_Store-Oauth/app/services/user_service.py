from bson import ObjectId
from datetime import datetime, timezone
from motor.motor_asyncio import AsyncIOMotorDatabase
from fastapi import HTTPException
from app.models.pydantic.user_pydantic import GetUserByIdResponse, Review
from app.models.pydantic.base_model import IdName
from app.models.db.user_model import User
from app.utils.token_util import get_hashed_password

# retreive a list of users
async def get_users(db : AsyncIOMotorDatabase,  limit : int = 20, offset : int = 0, search : str = None):
    collection = db['users']
    if search:
        cursor = collection.find({
            "$or": [
                {"username": {"$regex": search, "$options": "i"}},  
                {"email": {"$regex": search, "$options": "i"}}
            ]
        }).skip(offset).limit(limit)
    else:
        cursor = collection.find().skip(offset).limit(limit)

    results = [cat async for cat in cursor]
    print(results)
    for cat in results:
        cat['id'] = str(cat['_id'])
        del cat['password']
        del cat['_id']
    count = len(results)
    print(results)
    return {
        "count": count,
        "next": None,
        "previous": None,
        "results": results
    }

# create a user
async def create_user(data : dict, db = AsyncIOMotorDatabase):
    collection = db["users"]
    if(await collection.find_one({"username": {"$regex": f"^{data['username']}$", "$options": "i"}})):
        raise HTTPException(status_code=400, detail="username already exists")
    data['password'] = get_hashed_password(data['password'])
    data = User(**data)
    result = await collection.insert_one(data.model_dump())
    data = data.model_dump()
    data['id'] = str(result.inserted_id)
    del data['password']
    return data

# retreive a specific user by user_id
async def get_user_by_id(user_id: str, db: AsyncIOMotorDatabase):
    if not ObjectId.is_valid(user_id):
        raise HTTPException(status_code=400, detail="Invalid user ID")

    collection = db["users"]

    pipeline = [
        {'$match': {'_id': ObjectId(user_id)}},
        {
            '$lookup': {
                'from': 'reviews',
                'let': {'uid': user_id},
                'pipeline': [
                    {'$match': {
                        '$expr': {'$eq': ['$user_id', '$$uid']}
                    }},
                    {'$sort': {'created_at': -1}},
                    {'$limit': 2},
                    {
                        '$addFields': {
                            'book_obj_id': {'$toObjectId': '$book_id'}
                        }
                    },
                    {
                        '$lookup': {
                            'from': 'books',
                            'localField': 'book_obj_id',
                            'foreignField': '_id',
                            'as': 'book_obj'
                        }
                    },
                    {
                        '$addFields': {
                            'book_details': {'$arrayElemAt': ['$book_obj', 0]}
                        }
                    }
                ],
                'as': 'recent_reviews'
            }
        }
    ]

    results = await collection.aggregate(pipeline).to_list(length=1)

    if not results:
        raise HTTPException(status_code=404, detail="user not found")

    user = results[0]
    user['id'] = str(user['_id'])

    recent_reviews = []
    for review in user.get("recent_reviews", []):
        review['id'] = str(review['_id'])
        book_doc = review.get('book_details')
        book = IdName(id=str(book_doc['_id']), name=book_doc['title']) if book_doc else None
        recent_reviews.append(Review(**review, book=book))
        
    user.pop("_id", None)
    user.pop("recent_reviews", None)

    return GetUserByIdResponse(**user, recent_reviews=recent_reviews)

    
# Update an existing user
async def update_user(user_id: str, data: dict, db : AsyncIOMotorDatabase):
    collection = db["users"]
    if not ObjectId.is_valid(user_id):
        raise HTTPException(status_code=400, detail="Invalid user ID")
    user_data = await collection.find_one({"_id": ObjectId(user_id)})
    if not user_data:
        raise HTTPException(status_code=404, detail="user not found")
    data['updated_at'] = datetime.now(timezone.utc)
    data['password'] = get_hashed_password(data['password'])
    result = await collection.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": data}
    )
    updated_data = await collection.find_one({"_id": ObjectId(user_id)})
    updated_data['id'] = str(updated_data['_id'])
    del updated_data['password']
    del updated_data['_id']
    return updated_data if result.modified_count else None