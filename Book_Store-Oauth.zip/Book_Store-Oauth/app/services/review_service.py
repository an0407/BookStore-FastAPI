from bson import ObjectId
from fastapi import HTTPException
from datetime import datetime, timezone
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.models.db.review_model import Review
from app.models.pydantic.base_model import User, User2
from app.models.pydantic.review_pydantic import (ReviewCreate, 
                                                 CreateReviewResponse, 
                                                 GetReviewsResponse, 
                                                 GetReviewByIDResponse)


# get a list of reviews
async def get_reviews(
    db: AsyncIOMotorDatabase,
    limit: int = 20,
    offset: int = 0,
    rating: int = None,
    order_by: str = None
):
    if order_by not in ['newest', 'highest_rated']:
        raise HTTPException(status_code=400, detail='Invalid order_by criteria')

    match_stage = {}
    if rating is not None:
        match_stage['rating'] = rating

    # Determine sort order
    sort_stage = []
    if order_by == 'newest':
        sort_stage = [("updated_at", -1), ("created_at", -1)]
    elif order_by == 'highest_rated':
        sort_stage = [("rating", -1), ("created_at", -1)]

    pipeline = []

    if match_stage:
        pipeline.append({'$match': match_stage})

    # Convert user_id string to ObjectId for lookup
    pipeline.extend([
        {
            '$addFields': {
                'user_obj_id': {'$toObjectId': '$user_id'}
            }
        },
        {
            '$lookup': {
                'from': 'users',
                'localField': 'user_obj_id',
                'foreignField': '_id',
                'as': 'user_obj'
            }
        },
        {
            '$addFields': {
                'user_details': {'$arrayElemAt': ['$user_obj', 0]}
            }
        }
    ])

    if sort_stage:
        pipeline.append({'$sort': dict(sort_stage)})

    pipeline.extend([
        {'$skip': offset},
        {'$limit': limit}
    ])

    results = await db['reviews'].aggregate(pipeline).to_list(length=limit)

    updated_results = []
    for review in results:
        review['id'] = str(review['_id'])
        user_doc = review.get('user_details')
        user = User(id=str(user_doc['_id']), username=user_doc['username']) if user_doc else None
        updated_results.append(CreateReviewResponse(**review, user=user))

    return GetReviewsResponse(count=len(results), results=updated_results)

# create a new review
async def create_review(book_id : str, user_id : str, review : ReviewCreate, db : AsyncIOMotorDatabase):
    collection = db['reviews']
    data = {
        'book_id' : book_id,
        'user_id' : user_id,
        'rating' : review.rating,
        'title' : review.title,
        'comment' : review.comment
    }
    data = Review(**data)
    result = await collection.insert_one(data.model_dump())
    data = data.model_dump()
    await db['users'].update_one({"_id": ObjectId(user_id)}, {"$inc": {"review_count": 1}})
    total_rating = 0
    count = 0
    cursor = collection.find({'book_id' : book_id})
    async for review in cursor:
        total_rating += review['rating']
        count += 1
    avg_rating = total_rating / count if count > 0 else 0
    await db['books'].update_one(
    {'_id': ObjectId(book_id)},
    {'$set': {'average_rating': avg_rating}})
    data['id'] = str(result.inserted_id)
    user = await db['users'].find_one({'_id' : ObjectId(user_id)})
    user['id'] = str(user['_id'])
    return CreateReviewResponse(**data, user = user)

# retreive a review by id
async def get_review_by_id(review_id: str, db: AsyncIOMotorDatabase):
    if not ObjectId.is_valid(review_id):
        raise HTTPException(status_code=400, detail="Invalid review ID")

    collection = db["reviews"]

    pipeline = [
        {'$match': {'_id': ObjectId(review_id)}},
        {
            '$addFields': {
                'user_obj_id': {'$toObjectId': '$user_id'}
            }
        },
        {
            '$lookup': {
                'from': 'users',
                'localField': 'user_obj_id',
                'foreignField': '_id',
                'as': 'user_obj'
            }
        },
        {
            '$addFields': {
                'user_details': {'$arrayElemAt': ['$user_obj', 0]}
            }
        }
    ]

    results = await collection.aggregate(pipeline).to_list(length=1)

    if not results:
        raise HTTPException(status_code=404, detail="review not found")

    review = results[0]
    review['id'] = str(review['_id'])

    user_doc = review.get('user_details')
    user = User2(id=str(user_doc['_id']), username=user_doc['username'], first_name = user_doc['first_name'],
                 last_name = user_doc['last_name']) if user_doc else None

    return GetReviewByIDResponse(**review, user=user)


# Update an existing review
async def update_review(review_id: str, data: dict, db : AsyncIOMotorDatabase):
    collection = db["reviews"]
    if not ObjectId.is_valid(review_id):
        raise HTTPException(status_code=400, detail="Invalid review ID")
    review_data = await collection.find_one({"_id": ObjectId(review_id)})
    if not review_data:
        raise HTTPException(status_code=404, detail="review not found")
    
    data['updated_at'] = datetime.now(timezone.utc)
    result = await collection.update_one(
        {"_id": ObjectId(review_id)},
        {"$set": data}
    )
    review = await collection.find_one({"_id": ObjectId(review_id)})

    total_rating = 0
    count = 0
    cursor = collection.find({'book_id' : review['book_id']})
    async for review in cursor:
        total_rating += review['rating']
        count += 1
    avg_rating = total_rating / count if count > 0 else 0
    await db['books'].update_one(
    {'_id': ObjectId(review['book_id'])},
    {'$set': {'average_rating': avg_rating}})

    user = await db['users'].find_one({'_id' : ObjectId(review['user_id'])})
    review['id'] = str(review['_id'])
    user['id'] = str(user['_id'])
    return CreateReviewResponse(**review, user = User(**user)) if result.modified_count else None