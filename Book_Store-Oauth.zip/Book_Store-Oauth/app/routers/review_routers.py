from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from typing import Annotated
from fastapi import APIRouter, Depends, Query, HTTPException
from app.models.pydantic.review_pydantic import ReviewCreate, ReviewUpdate, CreateReviewResponse, GetReviewByIDResponse, GetReviewsResponse
from app.models.pydantic.auth_pydantic import TokenPayload
from app.database import get_database
from app.utils.token_util import get_current_user
from app.services import review_service

router = APIRouter(prefix = '/books/{book_id}/reviews', tags = ['reviews'])

# Retrieve a list of reviews
@router.get("/", response_model=GetReviewsResponse)
async def list_reviews(db: AsyncIOMotorDatabase = Depends(get_database), limit: int = Query(20), offset: int = Query(0), 
                       rating : int = Query(None), 
                       order_by : Annotated[str, Query(description='Enter "highest_rated" or "newest", default it is "newest"')] = 'newest'):
    return await review_service.get_reviews(db, limit, offset, rating, order_by)

# Create a new review
@router.post('/', response_model = CreateReviewResponse)
async def create_review(current_user: Annotated[dict, Depends(get_current_user)], book_id : str, user_id : str, review : ReviewCreate, db : AsyncIOMotorDatabase = Depends(get_database)):
    if(user_id != current_user['id']):
        raise HTTPException(status_code=401, detail= 'Not authorised to create review')  
    return await review_service.create_review(book_id, user_id, review, db)


# Retrieve details of a specific review by id
@router.get("/{review_id}", response_model= GetReviewByIDResponse)
async def get_review(review_id : str, db: AsyncIOMotorDatabase = Depends(get_database)):
    return await review_service.get_review_by_id(review_id, db)

# Update an existing review
@router.put("/{review_id}", response_model=CreateReviewResponse)
async def update_review(current_user: Annotated[dict, Depends(get_current_user)], review_id : str, update_data: ReviewUpdate, db: AsyncIOMotorDatabase = Depends(get_database)):
    
    existing_review = await db['reviews'].find_one({"_id": ObjectId(review_id)})
    if(existing_review['user_id'] != current_user['id']):
        raise HTTPException(status_code=401, detail='unauthorized to update this review')
    return await review_service.update_review(
        review_id, update_data.model_dump(exclude_unset=True), db
    )