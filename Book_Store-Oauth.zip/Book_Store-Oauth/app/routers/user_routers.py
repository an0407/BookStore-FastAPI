from fastapi import APIRouter, Depends, Query, HTTPException
from typing import Annotated
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.models.pydantic.user_pydantic import UserCreate, UserUpdate, UserCreateResponse, GetUserByIdResponse, GetUsersResponse
from app.services import user_service
from app.database import get_database
from app.utils.token_util import get_current_user

router = APIRouter(prefix = '/users', tags = ['users'])

# Retrieve a list of users
@router.get("/", response_model=GetUsersResponse)
async def list_users(db: AsyncIOMotorDatabase = Depends(get_database), limit: int = Query(20), offset: int = Query(0), 
                       search : str = Query(None)):
    return await user_service.get_users(db, limit, offset, search)

# create a new book
@router.post('/', response_model= UserCreateResponse)
async def create_user(user : UserCreate, db : AsyncIOMotorDatabase = Depends(get_database)):
    return await user_service.create_user(user.model_dump(), db)

# Retrieve details of a specific user by id
@router.get("/{user_id}", response_model= GetUserByIdResponse)
async def get_user(current_user: Annotated[dict, Depends(get_current_user)], user_id : str, db: AsyncIOMotorDatabase = Depends(get_database)):
    if current_user['id'] != user_id:
        raise HTTPException(status_code=404, detail="Not Authorized to access this user")
    return await user_service.get_user_by_id(user_id, db)

# Update an existing user
@router.put("/{user_id}", response_model=UserCreateResponse)
async def update_user(current_user: Annotated[dict, Depends(get_current_user)], user_id : str, update_data: UserUpdate, db: AsyncIOMotorDatabase = Depends(get_database)):
    if current_user['id'] != user_id:
        raise HTTPException(status_code=404, detail="Not Authorized to access this user")
    return await user_service.update_user(
        user_id, update_data.model_dump(exclude_unset=True), db
    )