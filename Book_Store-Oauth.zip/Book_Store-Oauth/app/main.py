from fastapi import FastAPI
from app.routers import category_routers, author_routers, book_routers, user_routers, review_routers, auth_routers

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "   add '/docs' to this url's endpoint to get the automatic swagger API documentation to access all APIs   "}

app.include_router(category_routers.router)
app.include_router(author_routers.router)
app.include_router(book_routers.router)
app.include_router(user_routers.router)
app.include_router(review_routers.router)
app.include_router(auth_routers.auth_router)
