from pydantic import Field, BaseModel


class Auth(BaseModel):
    username : str = Field(...)
    password : str = Field(...) 