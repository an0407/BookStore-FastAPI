from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime, timezone

class create(BaseModel):
    id : str
    created_at : datetime = Field(default_factory= lambda: datetime.now(timezone.utc))
    updated_at : Optional[datetime]

class update(BaseModel):
    id : str
    created_at : datetime = Field(default_factory= lambda : datetime.now(timezone.utc))
    updated_at : datetime = Field(default_factory= lambda : datetime.now(timezone.utc))

class IdName(BaseModel):
    id : str
    name : str

class Books(BaseModel):
    id : str
    title : str
    isbn : str
    publication_date : str

class User(BaseModel):
    id : str
    username : str

class User2(BaseModel):
    id : str
    username : str
    first_name : str
    last_name : str