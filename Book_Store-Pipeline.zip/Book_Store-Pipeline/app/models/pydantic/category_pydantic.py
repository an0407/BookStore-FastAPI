from pydantic import BaseModel, Field
from datetime import datetime, timezone
from typing import Optional, List
from app.models.pydantic.base_model import IdName, create, update

class CategoryCreate(create):
    name : str = Field(...)
    description : str = Field(...)
    book_count : int = Field(0)

class CategoryUpdateResponse(update):
    name : str = Field(...)
    description : str = Field(...)
    book_count : int = Field(0)

class CategoryIn(BaseModel):
    name : str = Field(..., examples = ['Fiction', 'Fantasy'])
    description : str = Field(..., examples = ['Description of Fiction'])

class BookInfo(BaseModel):
    id: str
    title: str
    author: IdName
    average_rating: float

class GetIdResponse(create):
    name: str
    description: str
    book_count: int
    top_books: List[BookInfo]

class GetCategoriesResponse(BaseModel):
    count : int
    next : Optional[str] = None
    previous : Optional[str] = None
    results: List[CategoryCreate]
