from bson import ObjectId
from fastapi import HTTPException
from datetime import datetime, timezone
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.models.db.book_model import Book
from app.models.pydantic.book_pydantic import BookCreateResponse, GetBooksResponse
from app.models.pydantic.base_model import IdName

# retreive a list of books
async def get_books(db : AsyncIOMotorDatabase,  limit : int = 20, offset : int = 0, author_id : str = None, category_ids : str = None):
    collection = db['books']
    match_stage = {'author_id' : '684126ff9f581f4c178afa64',
                   'category_ids' : {'$in': ['683ec94c7904b08cc07c930c']}}

    # Build match conditions
    if author_id:
        match_stage['author_id'] = author_id
    if category_ids:
        match_stage['category_ids'] = {'$in': [category_ids]}

    pipeline = []

    # Optional filtering
    if match_stage:
        pipeline.append({'$match': {'author_id' : '684126ff9f581f4c178afa64',
                   'category_ids' : {'$in': ['683ec94c7904b08cc07c930c']}}})

    # Convert string author_id to ObjectId
    pipeline += [
        {
            '$addFields': {
                'author_obj_id': {'$toObjectId': '$author_id'},
                'category_obj_ids': {
                    '$map': {
                        'input': '$category_ids',
                        'as': 'cid',
                        'in': {'$toObjectId': '$$cid'}
                    }
                }
            }
        },
        {
            '$lookup': {
                'from': 'authors',
                'localField': 'author_obj_id',
                'foreignField': '_id',
                'as': 'author_obj'
            }
        },
        {
            '$addFields': {
                'author_details': {'$arrayElemAt': ['$author_obj', 0]}
            }
        },
        {
            '$lookup': {
                'from': 'categories',
                'localField': 'category_obj_ids',
                'foreignField': '_id',
                'as': 'categories_details'
            }
        },
        {'$skip': offset},
        {'$limit': limit}
    ]

    results = await collection.aggregate(pipeline).to_list(length=limit)

    listofbooks = []
    for book in results:
        book['id'] = str(book['_id'])

        # Convert author object
        author_doc = book.get('author_details')
        author = IdName(id=str(author_doc['_id']), name=author_doc['name']) if author_doc else None

        # Convert categories
        categories = [
            IdName(id=str(cat['_id']), name=cat['name']) for cat in book.get('categories_details', [])
        ]

        listofbooks.append(BookCreateResponse(**book, author=author, categories=categories))

    count = len(listofbooks)
    return GetBooksResponse(count=count, results=listofbooks)

# create a book
async def create_book(data : dict, db = AsyncIOMotorDatabase):
    collection = db["books"]
    if(await collection.find_one({"title": {"$regex": f"^{data['title']}$", "$options": "i"}})):
        raise HTTPException(status_code=400, detail="book already exists")
    data = Book(**data)
    result = await collection.insert_one(data.model_dump())
    data = data.model_dump()
    data['id'] = str(result.inserted_id)
    for category_id in data['category_ids']:
        await db['categories'].update_one({"_id": ObjectId(category_id)}, {"$inc": {"book_count": 1}})
    await db['authors'].update_one({"_id": ObjectId(data['author_id'])}, {"$inc": {"book_count": 1}})
    author = await db['authors'].find_one({'_id' : ObjectId(data['author_id'])})
    author['id'] = str(author['_id'])
    categories_list = []
    for category_id in data['category_ids']:
        category = await db['categories'].find_one({'_id' : ObjectId(category_id)})
        category['id'] = str(category['_id'])
        categories_list.append(IdName(**category))
    return BookCreateResponse(**data, author = IdName(**author), categories = categories_list)

# retreive a specific book by book_id
async def get_book_by_id(book_id: str, db: AsyncIOMotorDatabase):
    if not ObjectId.is_valid(book_id):
        raise HTTPException(status_code=400, detail="Invalid book ID")

    collection = db["books"]

    pipeline = [
        {
            '$match': {'_id': ObjectId(book_id)}
        },
        {
            '$addFields': {
                'author_obj_id': {'$toObjectId': '$author_id'},
                'category_obj_ids': {
                    '$map': {
                        'input': '$category_ids',
                        'as': 'cid',
                        'in': {'$toObjectId': '$$cid'}
                    }
                }
            }
        },
        {
            '$lookup': {
                'from': 'authors',
                'localField': 'author_obj_id',
                'foreignField': '_id',
                'as': 'author_obj'
            }
        },
        {
            '$addFields': {
                'author_details': {'$arrayElemAt': ['$author_obj', 0]}
            }
        },
        {
            '$lookup': {
                'from': 'categories',
                'localField': 'category_obj_ids',
                'foreignField': '_id',
                'as': 'categories_details'
            }
        }
    ]

    results = await collection.aggregate(pipeline).to_list(length=1)
    if not results:
        raise HTTPException(status_code=404, detail="Book not found")

    book = results[0]
    book['id'] = str(book['_id'])

    # Convert author
    author_doc = book.get('author_details')
    author = IdName(id=str(author_doc['_id']), name=author_doc['name']) if author_doc else None

    # Convert categories
    categories = [
        IdName(id=str(cat['_id']), name=cat['name'])
        for cat in book.get('categories_details', [])
    ]

    return BookCreateResponse(**book, author=author, categories=categories)

# Update an existing book
async def update_book(book_id: str, data: dict, db : AsyncIOMotorDatabase):
    collection = db["books"]
    if not ObjectId.is_valid(book_id):
        raise HTTPException(status_code=400, detail="Invalid book ID")
    old_data = await collection.find_one({"_id": ObjectId(book_id)})
    if not old_data:
        raise HTTPException(status_code=404, detail="book not found") 
    data['updated_at'] = datetime.now(timezone.utc)
    result = await collection.update_one(
        {"_id": ObjectId(book_id)},
        {"$set": data}
    )
    data = await collection.find_one({'_id' : ObjectId(book_id)})
    data['id'] = str(data['_id'])
    if(data['category_ids'] != old_data['category_ids']):
        for i in data['category_ids']:
            flag = 0
            for j in old_data['category_ids']:
                if(i == j):
                    flag = 1
            if(flag == 0):
                await db['categories'].update_one({"_id": ObjectId(i)}, {"$inc": {"book_count": 1}})
        for i in old_data['category_ids']:
            flag = 0
            for j in data['category_ids']:
                if(i == j):
                    flag = 1
            if(flag == 0):
                await db['categories'].update_one({"_id": ObjectId(i)}, {"$inc": {"book_count": -1}})
    
    author = await db['authors'].find_one({'_id' : ObjectId(data['author_id'])})
    author['id'] = str(author['_id'])
    categories_list = []
    for category_id in data['category_ids']:
        category = await db['categories'].find_one({'_id' : ObjectId(category_id)})
        category['id'] = str(category['_id'])
        categories_list.append(IdName(**category))

    return BookCreateResponse(**data, author = IdName(**author), categories = categories_list) if result.modified_count else None
