from fastapi import FastAPI
from contextlib import asynccontextmanager

from app.models.db.review_model import Review
from app.models.db.author_model import Author
from app.models.db.book_model import Book
from app.models.db.category_model import Category
from app.models.db.user_model import User

from app.database import Base, engine
from app.routers import category_routers, author_routers, book_routers, user_routers, review_routers, auth_routers


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as create:
        await create.run_sync(Base.metadata.create_all)
        
    yield

app = FastAPI(lifespan=lifespan)

@app.get("/")
async def root():
    return {"message": "   add '/docs' to this url's endpoint to get the automatic swagger API documentation to access all APIs   "}

app.include_router(category_routers.router)
app.include_router(author_routers.router)
app.include_router(book_routers.router)
app.include_router(user_routers.router)
app.include_router(review_routers.router)
app.include_router(auth_routers.auth_router)