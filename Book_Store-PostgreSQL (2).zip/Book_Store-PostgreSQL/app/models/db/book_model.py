from sqlalchemy import (
    Column, ForeignKey, Integer, String, Float,
    DateTime, Text, ARRAY
)
from sqlalchemy.orm import relationship

from app.database import Base
from datetime import datetime, timezone

class Book(Base):
    __tablename__ = 'books'

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    isbn = Column(String, unique=True)
    publication_date = Column(String)
    description = Column(Text)
    page_count = Column(Integer)
    language = Column(String)

    author_id = Column(Integer, ForeignKey('authors.id'), nullable=False)
    category_ids = Column(ARRAY(Integer), nullable=False, default=list)

    average_rating = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=True)

    author = relationship("Author", back_populates="books")
    reviews = relationship("Review", back_populates="book")
