from sqlalchemy import (
    Column, Integer, String,
    DateTime, Text, Date
)
from sqlalchemy.orm import relationship
from app.database import Base
from datetime import datetime, timezone

class Author(Base):
    __tablename__ = 'authors'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    biography = Column(Text)
    birth_date = Column(String)
    death_date = Column(String, nullable=True)
    country = Column(String)
    book_count = Column(Integer, default=0)  # updated in application logic
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=True)

    books = relationship("Book", back_populates="author")