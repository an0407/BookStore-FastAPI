from sqlalchemy import (
    Column, ForeignKey, Integer, String,
    DateTime, Text, Float
)
from sqlalchemy.orm import relationship
from app.database import Base
from datetime import datetime, timezone

class Review(Base):
    __tablename__ = 'reviews'

    id = Column(Integer, primary_key=True, index=True)
    book_id = Column(Integer, ForeignKey('books.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    rating = Column(Float, nullable=False)
    title = Column(String)
    comment = Column(Text)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), nullable=True)

    book = relationship("Book", back_populates="reviews")
    user = relationship("User", back_populates="reviews")