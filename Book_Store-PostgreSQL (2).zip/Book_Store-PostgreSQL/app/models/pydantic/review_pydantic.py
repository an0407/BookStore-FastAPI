from pydantic import BaseModel, Field
from datetime import datetime, timezone
from typing import Optional, List
from app.models.pydantic.base_model import User, User2, create

class ReviewCreate(BaseModel):
    rating: float = Field(..., examples=[4.5, 3, 2])
    title: str = Field(..., examples=['Great Book', 'A Masterpiece'])
    comment: str = Field(..., examples=['over the years this classic has sustained due to its persistent writing'])

class ReviewUpdate(BaseModel):
    rating: float = Field(..., examples=[4.5, 3, 2])
    title: str = Field(..., examples=['Great Book', 'A Masterpiece'])
    comment: str = Field(..., examples=['over the years this classic has sustained due to its persistent writing'])

class CreateReviewResponse(create):
    book_id: int = Field(...)
    user : User
    rating: float = Field(...)  
    title: str = Field(...)
    content: str = Field(None)

class GetReviewByIDResponse(create):
    book_id: int = Field(...)
    user : User2
    rating: float = Field(...)  
    title: str = Field(...)
    content: str = Field(None)

class GetReviewsResponse(BaseModel):
    count : int
    next : Optional[str] = None
    previous : Optional[str] = None
    results : List[CreateReviewResponse]