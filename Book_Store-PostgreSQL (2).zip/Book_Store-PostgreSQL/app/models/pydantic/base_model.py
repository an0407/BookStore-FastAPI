from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime, timezone

class create(BaseModel):
    id : int
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at : Optional[datetime]

class update(BaseModel):
    id : int
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class IdName(BaseModel):
    id : int
    name : str

class Books(BaseModel):
    id : int
    title : str
    isbn : str
    publication_date : str

class User(BaseModel):
    id : int
    username : str

    model_config = ConfigDict(from_attributes=True)

class User2(BaseModel):
    id : int
    username : str
    first_name : str
    last_name : str

    model_config = ConfigDict(from_attributes=True)