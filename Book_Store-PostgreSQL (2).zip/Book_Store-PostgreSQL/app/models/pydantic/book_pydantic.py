from pydantic import BaseModel, Field
from datetime import datetime, timezone
from typing import Optional, List
from app.models.pydantic.base_model import create, IdName

class BookCreate(BaseModel):
    title: str = Field(..., examples=['Percy Jackson','Harry Potter'])
    isbn : str = Field(..., examples=[9780743273565])
    publication_date: str = Field(..., examples=['01-09-1976', '12-07-1999'])  
    description: str = Field(..., examples=['this is astory of how percy jackson fought the mythological demons'])
    page_count: int =Field(..., examples=[111,145,217])
    language: str = Field(..., examples= ['en','fr','pl'])
    author_id: int = Field(..., examples=[1, 2])
    category_ids: List[int] = Field(...)

class BookUpdate(BaseModel):
    title: str = Field(..., examples=['Percy Jackson','Harry Potter'])
    isbn : str = Field(..., examples=[9780743273565])
    publication_date: str = Field(..., examples=['01-09-1976', '12-07-1999'])  
    description: str = Field(..., examples=['this is astory of how percy jackson fought the mythological demons'])
    page_count: int =Field(..., examples=[111,145,217])
    language: str = Field(..., examples= ['en','fr','pl'])
    author_id: int = Field(..., examples=['6846e87dc1fdc1de949e26e2', '68401f01a646ce559212c95d'])
    category_ids: List[int] = Field(...)

class BookCreateResponse(create):
    title: str
    isbn : str
    publication_date: str = Field(...)  
    description: str = Field(...)
    page_count: int =Field(...)
    language: str = Field(...)
    author: IdName
    categories: List[IdName]
    average_rating : float

class GetBooksResponse(BaseModel):
    count : int
    next : Optional[str] = None
    previous : Optional[str] = None
    results : List[BookCreateResponse]