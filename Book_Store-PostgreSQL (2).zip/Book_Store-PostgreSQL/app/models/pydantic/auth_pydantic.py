from datetime import datetime
from pydantic import BaseModel, Field

class TokenRequest(BaseModel):
    id: int
    username: str

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str

class TokenPayload(BaseModel):  
    user_id : int
    exp: datetime
    token_type: str
    valid: bool = True

class UserLogin(BaseModel):
    username: str = Field(...,examples=["bookreader"])
    password: str = Field(...,examples=["user@1234"])
