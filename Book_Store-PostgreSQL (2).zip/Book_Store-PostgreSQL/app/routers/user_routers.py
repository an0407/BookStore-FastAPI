from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.pydantic.user_pydantic import UserCreate, UserUpdate, UserCreateResponse, GetUserByIdResponse, GetUsersResponse
from app.services import user_service
from app.utils.dependencies import get_current_user
from app.database import get_async_session

router = APIRouter(prefix = '/users', tags = ['users'])

# Retrieve a list of users
@router.get("/", response_model=GetUsersResponse)
async def list_users(db: AsyncSession = Depends(get_async_session), limit: int = Query(20), offset: int = Query(0), 
                       search : str = Query(None)):
    return await user_service.get_users(db, limit, offset, search)

# create a new book
@router.post('/', response_model= UserCreateResponse)
async def create_user(user : UserCreate, db : AsyncSession = Depends(get_async_session)):
    return await user_service.create_user(user.model_dump(), db)

# Retrieve details of a specific user by id
@router.get("/{user_id}", response_model= GetUserByIdResponse)
async def get_user(user_id : int, db: AsyncSession = Depends(get_async_session), current_user = Depends(get_current_user)):
    if current_user.user_id != user_id:
        raise HTTPException(status_code=404, detail="Not Authorized to access this user")
    return await user_service.get_user_by_id(user_id, db)

# Update an existing user
@router.put("/{user_id}", response_model=UserCreateResponse)
async def update_user(user_id : int, update_data: UserUpdate, db: AsyncSession = Depends(get_async_session), 
                      current_user = Depends(get_current_user)):
    if current_user.user_id != user_id:
        raise HTTPException(status_code=404, detail="Not Authorized to access this user")
    
    return await user_service.update_user(user_id, update_data.model_dump(exclude_unset=True), db)