from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_async_session
from app.services.auth_service import AuthService
from app.models.pydantic.user_pydantic import UserCreate
from app.models.pydantic.auth_pydantic import UserLogin, TokenResponse

auth_router = APIRouter(prefix="/auth", tags=["Auth"])

@auth_router.post("/login", response_model=TokenResponse)
async def login(user: UserLogin, db: AsyncSession = Depends(get_async_session)):
    return await AuthService(db).login_user(user)

@auth_router.post("/register", response_model=TokenResponse)
async def register(user: UserCreate, db: AsyncSession = Depends(get_async_session)):
    return await AuthService(db).register_user(user)
