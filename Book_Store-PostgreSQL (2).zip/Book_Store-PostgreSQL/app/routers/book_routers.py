from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_async_session
from app.services import book_service
from app.models.pydantic.book_pydantic import BookCreate, BookUpdate, BookCreateResponse, GetBooksResponse
from app.models.db.book_model import Book

router = APIRouter(prefix = '/books', tags=['books'])

# Retrieve a list of books
@router.get("/", response_model=GetBooksResponse)
async def list_books(db: AsyncSession = Depends(get_async_session), limit: int = Query(20), offset: int = Query(0),
                     author_id : int = Query(None), category_id : int = Query(None)):
    return await book_service.get_books(db, limit, offset, author_id, category_id)

# create a new book
@router.post('/', response_model= BookCreateResponse)
async def create_book(book : BookCreate, db : AsyncSession = Depends(get_async_session)):
    return await book_service.create_book(book.model_dump(), db)

# Retrieve details of a specific book by id
@router.get("/{book_id}", response_model= BookCreateResponse)
async def get_book(book_id : int, db: AsyncSession = Depends(get_async_session)):
    try:
        return await book_service.get_book_by_id(book_id, db)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

# Update an existing book
@router.put("/{author_id}", response_model=BookCreateResponse)
async def update_book(book_id: int, update_data: BookUpdate, db: AsyncSession = Depends(get_async_session)):
    try:
        return await book_service.update_book(
            book_id, update_data.model_dump(exclude_unset=True), db
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))