from fastapi import APIRouter, Query, Depends, HTTPException
from app.services import category_service
from app.models.pydantic.category_pydantic import CategoryCreate, CategoryIn, GetIdResponse, GetCategoriesResponse, CategoryUpdateResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_async_session

router = APIRouter(prefix='/categories', tags=['categories'])

# Retrieve a list of book categories
@router.get("/", response_model= GetCategoriesResponse)
async def list_categories(db: AsyncSession = Depends(get_async_session), limit: int = Query(50), offset: int = Query(0)):
    return await category_service.get_categories(db, limit, offset)

# Create a new category
@router.post("/", response_model=CategoryCreate)
async def create_category(category: CategoryIn, db: AsyncSession = Depends(get_async_session)):
    return await category_service.create_category(category.model_dump(), db)

# Retrieve details of a specific category by id
@router.get("/{category_id}", response_model=GetIdResponse)
async def get_category(category_id: int, db: AsyncSession = Depends(get_async_session)):
    try:
        return await category_service.get_category_by_id(category_id, db)
    except HTTPException as e:
        raise e

# Update an existing category
@router.put("/{category_id}", response_model=CategoryUpdateResponse)
async def update_category(category_id: int, update_data: CategoryIn, db: AsyncSession = Depends(get_async_session)):
    try:
        return await category_service.update_category(
        category_id, update_data.model_dump(exclude_unset=True), db
    )
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))