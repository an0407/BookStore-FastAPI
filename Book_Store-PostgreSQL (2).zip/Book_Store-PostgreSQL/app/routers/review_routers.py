from sqlalchemy.ext.asyncio import AsyncSession
from bson import ObjectId
from typing import Annotated
from sqlalchemy import select
from fastapi import APIRouter, Depends, Query, HTTPException
from app.models.pydantic.review_pydantic import ReviewCreate, ReviewUpdate, CreateReviewResponse, GetReviewByIDResponse, GetReviewsResponse
from app.models.pydantic.auth_pydantic import TokenPayload
from app.models.db.review_model import Review
from app.database import get_async_session
from app.utils.dependencies import get_current_user
from app.services import review_service

router = APIRouter(prefix = '/books/{book_id}/reviews', tags = ['reviews'])

# Retrieve a list of reviews
@router.get("/", response_model=GetReviewsResponse)
async def list_reviews(db: AsyncSession = Depends(get_async_session), limit: int = Query(20), offset: int = Query(0), 
                       rating : float = Query(None), 
                       order_by : Annotated[str, Query(description='Enter "highest_rated" or "newest", default it is "newest"')] = 'newest'):
    return await review_service.get_reviews(db, limit, offset, rating, order_by)

# Create a new review
@router.post('/', response_model = CreateReviewResponse)
async def create_review(book_id : int, user_id : int, review : ReviewCreate, db : AsyncSession = Depends(get_async_session), 
                        current_user = Depends(get_current_user)):
    if(user_id != current_user.user_id):
        raise HTTPException(status_code=401, detail= 'Not authorised to create review')  
    return await review_service.create_review(book_id, user_id, review, db)


# Retrieve details of a specific review by id
@router.get("/{review_id}", response_model= GetReviewByIDResponse)
async def get_review(review_id : int, db: AsyncSession = Depends(get_async_session)):
    return await review_service.get_review_by_id(review_id, db)

# Update an existing review
@router.put("/{review_id}", response_model=CreateReviewResponse)
async def update_review(review_id : int, update_data: ReviewUpdate, db: AsyncSession = Depends(get_async_session),
                        current_user: TokenPayload = Depends(get_current_user)):
    
    result = await db.execute(select(Review).where(Review.id == review_id))
    existing_review = result.scalar_one_or_none()

    if not existing_review:
        raise HTTPException(status_code=404, detail="Review not found")

    if existing_review.user_id != current_user.user_id:
        raise HTTPException(status_code=401, detail="Unauthorized to update this review")
    return await review_service.update_review(
        review_id, update_data.model_dump(exclude_unset=True), db
    )