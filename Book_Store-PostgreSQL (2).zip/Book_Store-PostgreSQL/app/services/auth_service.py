from datetime import datetime,timezone
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError
from app.models.pydantic.user_pydantic import UserCreate
from app.models.pydantic.auth_pydantic import UserLogin, TokenResponse
from app.models.db.user_model import User
from app.utils.token_util import get_hashed_password, verify_hashed_password, generate_tokens

class AuthService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def login_user(self, credentials: UserLogin) -> TokenResponse:
        query = select(User).where(User.username == credentials.username)
        result = await self.db.execute(query)
        user = result.scalar_one_or_none()

        if not user or not verify_hashed_password(credentials.password, user.password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )

        return generate_tokens(user.id)

    async def register_user(self, data: UserCreate) -> TokenResponse:
        existing_user = await self.db.execute(
            select(User).where(User.username == data.username)
        )
        if existing_user.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username already exists"
            )

        user_dict = data.model_dump()
        user_dict["password"] = get_hashed_password(user_dict["password"])
        user_dict["review_count"] = 0
        user_dict["created_at"] = datetime.now(timezone.utc)
        user_dict["updated_at"] = None

        new_user = User(**user_dict)


        self.db.add(new_user)
        try:
            await self.db.commit()
        except IntegrityError:
            await self.db.rollback()
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,detail="User registration failed")
        return generate_tokens(new_user.id)