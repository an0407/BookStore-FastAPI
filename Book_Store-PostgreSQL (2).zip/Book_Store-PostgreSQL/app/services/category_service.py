from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, cast, update, Integer
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.exc import IntegrityError
from fastapi import HTTPException

from app.models.db.category_model import Category
from app.models.db.book_model import Book
from app.models.db.author_model import Author
from app.models.pydantic.category_pydantic import GetCategoriesResponse, BookInfo, GetIdResponse
from app.models.pydantic.base_model import IdName

# Retrieve a list of book categories
async def get_categories(db: AsyncSession, limit: int = 50, offset: int = 0):
    result = await db.execute(
        select(Category).offset(offset).limit(limit)
    )
    categories = result.scalars().all()
    results = [category.__dict__ for category in categories]
    count = len(results)
    return GetCategoriesResponse(count=count, results=results)

# Retrieve details of a specific category by id
async def get_category_by_id(category_id: int, db: AsyncSession):
    result = await db.execute(select(Category).where(Category.id == category_id))
    category = result.scalar_one_or_none()
    if not category:
        raise HTTPException(status_code=404, detail="category not found")

    result = await db.execute(
    select(Book)
    .where(Book.category_ids.op("@>")(cast([category_id], ARRAY(Integer))))
    .order_by(Book.average_rating.desc())
    .limit(3))
    books = result.scalars().all()

    top_books = []
    for book in books:
        author_result = await db.execute(select(Author).where(Author.id == book.author_id))
        author = author_result.scalar_one()
        if author:
            top_books.append(BookInfo(**book.__dict__, author=IdName(**author.__dict__)))

    return GetIdResponse(**category.__dict__, top_books=top_books) if category else None

# Create a new category
async def create_category(data: dict, db : AsyncSession):
    result = await db.execute(select(Category).where(Category.name.ilike(data['name'])))
    existing_category = result.scalar_one_or_none()

    if existing_category:
        raise HTTPException(status_code=400, detail="Category already exists")

    # Create new category
    new_category = Category(**data)

    db.add(new_category)

    try:
        await db.commit()
        await db.refresh(new_category)  # Populate auto-generated fields like id
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to create category due to integrity error")
    
    return new_category.__dict__

# Update an existing category
async def update_category(category_id: int, data: dict, db: AsyncSession):
    result = await db.execute(select(Category).where(Category.id == category_id))
    category = result.scalar_one_or_none()
    if not category:
        raise HTTPException(status_code=404, detail="category not found")

    data['updated_at'] = datetime.now(timezone.utc)

    await db.execute(
        update(Category)
        .where(Category.id == category_id)
        .values(**data)
    )
    await db.commit()

    return await get_category_by_id(category_id, db)