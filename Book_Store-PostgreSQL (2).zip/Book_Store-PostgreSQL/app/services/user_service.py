from bson import ObjectId
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, update
from sqlalchemy.exc import IntegrityError
from fastapi import HTTPException
from app.models.pydantic.user_pydantic import GetUserByIdResponse, GetUsersResponse, UserCreateResponse
from app.models.db.user_model import User
from app.models.db.review_model import Review
from app.models.db.book_model import Book
from app.utils.token_util import get_hashed_password

# retreive a list of users
async def get_users(db: AsyncSession, limit: int = 20, offset: int = 0, search: str = None):
    if search:
        result = await db.execute(select(User).where(
            or_(
                User.username.ilike(f"%{search}%"),
                User.email.ilike(f"%{search}%")
                )).offset(offset).limit(limit))
    else:
        result = await db.execute(select(User).offset(offset).limit(limit))

    users = result.scalars().all()
    user_responses = [UserCreateResponse.model_validate(user) for user in users]

    count = len(user_responses)
    return GetUsersResponse(count=count, results=user_responses)

# create a user
async def create_user(data : dict, db = AsyncSession):
    result = await db.execute(select(User).where(User.username.ilike(data['username'])))
    existing_user = result.scalar_one_or_none()

    if existing_user:
        raise HTTPException(status_code=400, detail="user already exists")
    data['password'] = get_hashed_password(data['password'])
    
    new_user = User(**data)
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)

    new_user = new_user.__dict__
    del new_user['password']
    return new_user

# retreive a specific user by user_id
async def get_user_by_id(user_id: int, db: AsyncSession):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="user not found")

    result = await db.execute(
        select(Review)
        .where(Review.user_id == user_id)
        .order_by(Review.created_at.desc())
        .limit(2)
    )
    reviews = result.scalars().all()

    recent_reviews = []
    for review in reviews:
        book_result = await db.execute(select(Book).where(Book.id == review.book_id))
        book = book_result.scalar_one_or_none()
        if book:
            recent_reviews.append({
                "id": review.id,
                "book": {
                    "id": book.id,
                    "name": book.title
                },
                "rating": review.rating,
                "created_at": review.created_at
            })

    return GetUserByIdResponse(
        **user.__dict__,
        recent_reviews=recent_reviews
    )
    
# Update an existing user
async def update_user(user_id: int, data: dict, db: AsyncSession):
    # Check if user exists
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="user not found")

    # Prepare fields to update
    data["updated_at"] = datetime.now(timezone.utc)
    data["password"] = get_hashed_password(data["password"])

    # Perform update
    await db.execute(
        update(User)
        .where(User.id == user_id)
        .values(**data)
    )
    await db.commit()

    # Retrieve updated user
    result = await db.execute(select(User).where(User.id == user_id))
    updated_user = result.scalar_one()

    # Convert to dict (excluding password)
    user_dict = updated_user.__dict__
    user_dict.pop("password", None)
    
    return user_dict