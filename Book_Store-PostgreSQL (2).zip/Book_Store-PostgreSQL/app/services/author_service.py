from bson import ObjectId
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timezone
from fastapi import HTTPException, status

from app.models.db.author_model import Author
from app.models.db.book_model import Book
from app.models.pydantic.author_pydantic import GetAuthorsResponse, GetAuthorIdResponse
from app.models.pydantic.base_model import Books

# Retrieve a list of Authors
async def get_authors(db : AsyncSession, limit: int = 20, offset: int = 0, search : str = None):
    if search:
        result = await db.execute(select(Author).where(Author.name.ilike(f"%{search}%")).offset(offset).limit(limit))
        cursor = result.scalars().all()

    else:
        result = await db.execute(select(Author).offset(offset).limit(limit))
        cursor = result.scalars().all()
    results = [author.__dict__ for author in cursor]
    count = len(results)
    return GetAuthorsResponse(count = count, results = results)

# retreive a specific author by author_id
async def get_author_by_id(author_id: int, db: AsyncSession):
    # Fetch author
    result = await db.execute(select(Author).where(Author.id == author_id))
    author = result.scalar_one_or_none()
    if not author:
        raise HTTPException(status_code=404, detail="author not found")

    # Fetch books by this author
    result = await db.execute(select(Book).where(Book.author_id == author_id))
    books = result.scalars().all()

    # Convert books into response model
    books_by_author = [Books(**book.__dict__) for book in books]

    return GetAuthorIdResponse(**author.__dict__, books=books_by_author)

# create an author
async def create_author(data : dict, db = AsyncSession):
    result = await db.execute(select(Author).where(Author.name.ilike(data['name'])))
    existing_author = result.scalar_one_or_none()

    if existing_author:
        raise HTTPException(status_code=400, detail="Category already exists")

    # Create new category
    new_author = Author(**data)

    db.add(new_author)

    try:
        await db.commit()
        await db.refresh(new_author)  # Populate auto-generated fields like id
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to create category due to integrity error")
    
    return new_author.__dict__

# Update an existing author
async def update_author(author_id: int, data: dict, db: AsyncSession):
    result = await db.execute(select(Author).where(Author.id == author_id))
    author = result.scalar_one_or_none()
    
    if not author:
        raise HTTPException(status_code=404, detail="author not found")

    data['updated_at'] = datetime.now(timezone.utc)

    await db.execute(update(Author).where(Author.id == author_id).values(**data))
    await db.commit()

    result = await db.execute(select(Author).where(Author.id == author_id))
    updated_author = result.scalar_one_or_none()
    
    return updated_author