from bson import ObjectId
from fastapi import HTTPException
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import update, select, literal_column, func, desc
from app.models.db.review_model import Review
from app.models.db.book_model import Book
from app.models.db.user_model import User as Usr
from app.models.pydantic.base_model import User, User2
from app.models.pydantic.review_pydantic import (ReviewCreate, 
                                                 CreateReviewResponse, 
                                                 GetReviewsResponse, 
                                                 GetReviewByIDResponse)


# get a list of reviews
async def get_reviews(db : AsyncSession,  limit : int = 20, offset : int = 0, rating : float = None, 
                      order_by : str = None):
    if(order_by not in ['newest', 'highest_rated']):
        raise HTTPException(status_code=400, detail='Invalid order_by criteria')
    if rating is not None and order_by == 'newest':
        result = await db.execute(select(Review).where(Review.rating == rating).order_by(desc(Review.updated_at), desc(Review.created_at))
            .offset(offset).limit(limit))
        cursor = result.scalars().all()

    elif rating is not None and order_by == 'highest_rated':
        result = await db.execute(select(Review).where(Review.rating == rating).order_by(desc(Review.rating), desc(Review.created_at))
            .offset(offset).limit(limit))
        cursor = result.scalars().all()

    elif rating is None and order_by == 'newest':
        result = await db.execute(
            select(Review).order_by(desc(Review.updated_at), desc(Review.created_at)).offset(offset).limit(limit))
        cursor = result.scalars().all()

    elif rating is None and order_by == 'highest_rated':
        result = await db.execute(
            select(Review).order_by(desc(Review.rating), desc(Review.created_at)).offset(offset).limit(limit))
        cursor = result.scalars().all()

    else:
        result = await db.execute(select(Review).offset(offset).limit(limit))
        cursor = result.scalars().all()
    results = [cat for cat in cursor]
    updated_results = []
    for review in results:
        result = await db.execute(select(Usr).where(Usr.id == review.user_id))
        user = result.scalar_one_or_none()
        updated_results.append(CreateReviewResponse(**review.__dict__, user = User(**user.__dict__)))
    count = len(results)
    return GetReviewsResponse(count = count, results = updated_results)

# create a new review
async def create_review(book_id : int, user_id : int, review : ReviewCreate, db : AsyncSession):
    data = {
        'book_id' : book_id,
        'user_id' : user_id,
        'rating' : review.rating,
        'title' : review.title,
        'comment' : review.comment
    }
    data = Review(**data)
    db.add(data)
    await db.commit()
    await db.refresh(data)
    data = data.__dict__
    data['content'] = data['comment']

    await db.execute((
    update(Usr)
    .where(Usr.id == user_id)
    .values(review_count=literal_column("review_count") + 1)
    .execution_options(synchronize_session="fetch")
    ))
    await db.commit()

    total_rating = 0
    count = 0
    result = await db.execute(select(Review).where(Review.book_id == book_id))
    reviews = result.scalars().all()

    for review in reviews:
        total_rating += review.rating
        count += 1
    avg_rating = total_rating / count if count > 0 else 0

    await db.execute((
    update(Book)
    .where(Book.id == book_id)
    .values(average_rating=avg_rating)
    ))
    await db.commit()

    result = await db.execute(select(Usr).where(Usr.id == user_id))
    user = result.scalar_one_or_none()
    user = user.__dict__
    user = User(**user)
    return CreateReviewResponse(**data, user = user)

# retreive a review by id
async def get_review_by_id(review_id: int, db : AsyncSession):
    result = await db.execute(select(Review).where(Review.id == review_id))
    review = result.scalar_one_or_none()
    if not review:
        raise HTTPException(status_code=404, detail="review not found")
    result = await db.execute(select(Usr).where(Usr.id == review.user_id))
    user = result.scalar_one_or_none()
    return GetReviewByIDResponse(**review.__dict__, user = User2.model_validate(user)) if review else None

# Update an existing review
async def update_review(review_id: int, data: dict, db: AsyncSession):
    result = await db.execute(select(Review).where(Review.id == review_id))
    review = result.scalar_one_or_none()
    if not review:
        raise HTTPException(status_code=404, detail="review not found")

    data['updated_at'] = datetime.now(timezone.utc)
    await db.execute(
        update(Review)
        .where(Review.id == review_id)
        .values(**data)
    )
    await db.commit()

    book_id = review.book_id
    avg_result = await db.execute(
        select(func.avg(Review.rating)).where(Review.book_id == book_id)
    )
    avg_rating = avg_result.scalar() or 0

    await db.execute(
        update(Book)
        .where(Book.id == book_id)
        .values(average_rating=avg_rating)
    )
    await db.commit()

    result = await db.execute(select(Review).where(Review.id == review_id))
    updated_review = result.scalar_one()

    result = await db.execute(select(Usr).where(Usr.id == updated_review.user_id))
    user = result.scalar_one()

    return CreateReviewResponse(
        **updated_review.__dict__,
        user= User.model_validate(user)
    )