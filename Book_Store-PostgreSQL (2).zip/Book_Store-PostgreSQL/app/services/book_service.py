from fastapi import HTTPException
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy import select, update, cast, Integer
from sqlalchemy.exc import IntegrityError
from app.models.db.book_model import Book
from app.models.db.author_model import Author
from app.models.db.category_model import Category
from app.models.pydantic.book_pydantic import BookCreateResponse, GetBooksResponse
from app.models.pydantic.base_model import IdName

# retreive a list of books
async def get_books(db : AsyncSession,  limit : int = 20, offset : int = 0, author_id : int = None, category_id : int = None):
    if author_id and not category_id:
        result = await db.execute(
        select(Book)
        .where(Book.author_id == author_id)
        .offset(offset)
        .limit(limit))
        cursor = result.scalars().all()
    elif category_id and not author_id:
        result = await db.execute(
        select(Book)
        .where(Book.category_ids.op("@>")(cast([category_id], ARRAY(Integer)))).limit(limit).offset(offset))
        cursor = result.scalars().all()
    else:
        result = await db.execute(
        select(Book)
        .offset(offset)
        .limit(limit))
        cursor = result.scalars().all()

    results = [book for book in cursor]
    listofbooks = []
    for book in results:
        result = await db.execute(select(Author).where(Author.id == book.author_id))
        author = result.scalar_one_or_none()

        categories_list = []
        for category_id in book.category_ids:
            result = await db.execute(select(Category).where(Category.id == category_id))
            category = result.scalar_one_or_none()
            categories_list.append(IdName(**category.__dict__))
        listofbooks.append(BookCreateResponse(**book.__dict__, author = IdName(**author.__dict__), categories = categories_list))
    count = len(results)
    return GetBooksResponse(count = count, results = listofbooks)

# create a book
async def create_book(data : dict, db = AsyncSession):
    result = await db.execute(select(Book).where(Book.title.ilike(data['title'])))
    existing_book = result.scalar_one_or_none()

    if existing_book:
        raise HTTPException(status_code=400, detail="book already exists")
    new_book = Book(**data)

    db.add(new_book)

    try:
        await db.commit()
        await db.refresh(new_book)  # Populate auto-generated fields like id
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to create category due to integrity error")
    data = new_book.__dict__

    for category_id in data['category_ids']:
        await db.execute(
            update(Category)
            .where(Category.id == category_id)
            .values(book_count=Category.book_count + 1)
        )
    await db.commit()

    await db.execute(
        update(Author)
        .where(Author.id == data['author_id'])
        .values(book_count=Author.book_count + 1)
    )
    await db.commit()

    
    result = await db.execute(
    select(Author).where(Author.id == data['author_id'])
    )
    author = result.scalar_one_or_none()
    author = author.__dict__

    categories_list = []
    for category_id in data['category_ids']:
        result = await db.execute(
        select(Category).where(Category.id == category_id)
        )
        category = result.scalar_one_or_none()
        category = category.__dict__
        categories_list.append(IdName(**category))
    return BookCreateResponse(**data, author = IdName(**author), categories = categories_list)

# retreive a specific book by book_id
async def get_book_by_id(book_id: int, db: AsyncSession):
    result = await db.execute(select(Book).where(Book.id == book_id))
    book = result.scalar_one_or_none()

    if not book:
        raise HTTPException(status_code=404, detail="book not found")

    result = await db.execute(select(Author).where(Author.id == book.author_id))
    author = result.scalar_one_or_none()

    category_ids = book.category_ids
    if category_ids:
        result = await db.execute(select(Category).where(Category.id.in_(category_ids)))
        categories = result.scalars().all()
    categories=[IdName(**cat.__dict__) for cat in categories]

    return BookCreateResponse(
        **book.__dict__,
        author=IdName(**author.__dict__) if author else None,
        categories= categories
    )

# # Update an existing book
async def update_book(book_id: int, data: dict, db : AsyncSession):
    result = await db.execute(select(Book).where(Book.id == book_id))
    old_data = result.scalar_one_or_none()
    old_data = old_data.__dict__
    if not old_data:
        raise HTTPException(status_code=404, detail="book not found") 
    data['updated_at'] = datetime.now(timezone.utc)
    await db.execute(
    update(Book)
    .where(Book.id == book_id)
    .values(**data)
    )
    await db.commit()

    result = await db.execute(select(Book).where(Book.id == book_id))
    data = result.scalar_one_or_none()
    data = data.__dict__

    if(data['category_ids'] != old_data['category_ids']):
        for i in data['category_ids']:
            flag = 0
            for j in old_data['category_ids']:
                if(i == j):
                    flag = 1
            if(flag == 0):
                await db.execute(
                update(Category)
                .where(Category.id == i)
                .values(book_count=Category.book_count + 1))
                await db.commit()
        for i in old_data['category_ids']:
            flag = 0
            for j in data['category_ids']:
                if(i == j):
                    flag = 1
            if(flag == 0):
                await db.execute(
                update(Category)
                .where(Category.id == i)
                .values(book_count=Category.book_count - 1))
                await db.commit()
    
    result = await db.execute(select(Author).where(Author.id == data['author_id']))
    author = result.scalar_one_or_none()

    categories_list = []
    for category_id in data['category_ids']:
        result = await db.execute(select(Category).where(Category.id == category_id))
        category = result.scalar_one_or_none()
        categories_list.append(IdName(**category.__dict__))

    return BookCreateResponse(**data, author = IdName(**author.__dict__), categories = categories_list)
