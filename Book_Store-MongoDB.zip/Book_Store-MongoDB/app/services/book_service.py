from bson import ObjectId
from fastapi import HTTPException
from datetime import datetime, timezone
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.models.db.book_model import Book
from app.models.pydantic.book_pydantic import BookCreateResponse, GetBooksResponse
from app.models.pydantic.base_model import IdName

# retreive a list of books
async def get_books(db : AsyncIOMotorDatabase,  limit : int = 20, offset : int = 0, author_id : str = None, category_ids : str = None):
    collection = db['books']
    if author_id and not category_ids:
        cursor = collection.find({"author_id": author_id}).skip(offset).limit(limit)
    elif category_ids and not author_id:
        cursor = collection.find({"category_ids": category_ids}).skip(offset).limit(limit)
    else:
        cursor = collection.find().skip(offset).limit(limit)
    results = [cat async for cat in cursor]
    listofbooks = []
    for cat in results:
        cat['id'] = str(cat['_id'])
        author = await db['authors'].find_one({'_id' : ObjectId(cat['author_id'])})
        author['id'] = str(author['_id'])
        categories_list = []
        for category_id in cat['category_ids']:
            category = await db['categories'].find_one({'_id' : ObjectId(category_id)})
            category['id'] = str(category['_id'])
            categories_list.append(IdName(**category))
        listofbooks.append(BookCreateResponse(**cat, author = IdName(**author), categories = categories_list))
    count = len(results)
    return GetBooksResponse(count = count, results = listofbooks)

# create a book
async def create_book(data : dict, db = AsyncIOMotorDatabase):
    collection = db["books"]
    if(await collection.find_one({"title": {"$regex": f"^{data['title']}$", "$options": "i"}})):
        raise HTTPException(status_code=400, detail="book already exists")
    data = Book(**data)
    result = await collection.insert_one(data.model_dump())
    data = data.model_dump()
    data['id'] = str(result.inserted_id)
    for category_id in data['category_ids']:
        await db['categories'].update_one({"_id": ObjectId(category_id)}, {"$inc": {"book_count": 1}})
    await db['authors'].update_one({"_id": ObjectId(data['author_id'])}, {"$inc": {"book_count": 1}})
    author = await db['authors'].find_one({'_id' : ObjectId(data['author_id'])})
    author['id'] = str(author['_id'])
    categories_list = []
    for category_id in data['category_ids']:
        category = await db['categories'].find_one({'_id' : ObjectId(category_id)})
        category['id'] = str(category['_id'])
        categories_list.append(IdName(**category))
    return BookCreateResponse(**data, author = IdName(**author), categories = categories_list)

# retreive a specific book by book_id
async def get_book_by_id(book_id: str, db : AsyncIOMotorDatabase):
    collection = db["books"]
    if not ObjectId.is_valid(book_id):
        raise HTTPException(status_code=400, detail="Invalid book ID")
    book = await collection.find_one({"_id": ObjectId(book_id)})
    if not book:
        raise HTTPException(status_code=404, detail="book not found")
    book['id'] = str(book['_id'])
    author = await db['authors'].find_one({'_id' : ObjectId(book['author_id'])})
    author['id'] = str(author['_id'])
    categories_list = []
    for category_id in book['category_ids']:
        category = await db['categories'].find_one({'_id' : ObjectId(category_id)})
        category['id'] = str(category['_id'])
        categories_list.append(IdName(**category))
    return BookCreateResponse(**book, author = IdName(**author), categories = categories_list) if book else None

# Update an existing book
async def update_book(book_id: str, data: dict, db : AsyncIOMotorDatabase):
    collection = db["books"]
    if not ObjectId.is_valid(book_id):
        raise HTTPException(status_code=400, detail="Invalid book ID")
    old_data = await collection.find_one({"_id": ObjectId(book_id)})
    if not old_data:
        raise HTTPException(status_code=404, detail="book not found") 
    data['updated_at'] = datetime.now(timezone.utc)
    result = await collection.update_one(
        {"_id": ObjectId(book_id)},
        {"$set": data}
    )
    data = await collection.find_one({'_id' : ObjectId(book_id)})
    data['id'] = str(data['_id'])
    if(data['category_ids'] != old_data['category_ids']):
        for i in data['category_ids']:
            flag = 0
            for j in old_data['category_ids']:
                if(i == j):
                    flag = 1
            if(flag == 0):
                await db['categories'].update_one({"_id": ObjectId(i)}, {"$inc": {"book_count": 1}})
        for i in old_data['category_ids']:
            flag = 0
            for j in data['category_ids']:
                if(i == j):
                    flag = 1
            if(flag == 0):
                await db['categories'].update_one({"_id": ObjectId(i)}, {"$inc": {"book_count": -1}})
    
    author = await db['authors'].find_one({'_id' : ObjectId(data['author_id'])})
    author['id'] = str(author['_id'])
    categories_list = []
    for category_id in data['category_ids']:
        category = await db['categories'].find_one({'_id' : ObjectId(category_id)})
        category['id'] = str(category['_id'])
        categories_list.append(IdName(**category))

    return BookCreateResponse(**data, author = IdName(**author), categories = categories_list) if result.modified_count else None
