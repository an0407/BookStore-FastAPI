from datetime import datetime, timezone
from motor.motor_asyncio import AsyncIOMotorDatabase
from fastapi import HTTPException, status
from bson import ObjectId
from app.models.db.category_model import Category
from app.models.pydantic.category_pydantic import GetCategoriesResponse, BookInfo, GetIdResponse
from app.models.pydantic.base_model import IdName

# Retrieve a list of book categories
async def get_categories(db : AsyncIOMotorDatabase, limit: int = 50, offset: int = 0):
    collection = db["categories"]
    cursor = collection.find().skip(offset).limit(limit)
    results = [cat async for cat in cursor]
    for cat in results:
        cat['id'] = str(cat['_id'])
        del cat['_id']
    count = len(results)
    return GetCategoriesResponse(count = count, results = results)

# Retrieve details of a specific category by id
async def get_category_by_id(category_id: str, db : AsyncIOMotorDatabase):
    collection = db["categories"]
    if not ObjectId.is_valid(category_id):
        raise HTTPException(status_code=400, detail="Invalid category ID")
    category = await collection.find_one({"_id": ObjectId(category_id)})
    if not category:
        raise HTTPException(status_code=404, detail="category not found")
    print(category)
    top_books = []
    books = db['books'].find({"category_ids": category_id}).sort("average_rating", -1).limit(3)
    print(books)
    async for book in books:
        author = await db['authors'].find_one({'_id' : ObjectId(book['author_id'])})
        author['id'] = str(author['_id'])
        book['id'] = str(book['_id'])
        top_books.append(BookInfo(**book, author = IdName(**author)))
    category['id'] = str(category['_id'])
    return GetIdResponse(**category, top_books = top_books ) if category else None

# Create a new category
async def create_category(data: dict, db : AsyncIOMotorDatabase):
    collection = db["categories"]
    if(await collection.find_one({"name": {"$regex": f"^{data['name']}$", "$options": "i"}})):
        raise HTTPException(status_code=400, detail="category already exists")
    data = Category(**data)
    result = await collection.insert_one(data.model_dump())
    data = data.model_dump()
    data['id'] = str(result.inserted_id)
    return data

# Update an existing category
async def update_category(category_id: str, data: dict, db : AsyncIOMotorDatabase):
    collection = db["categories"]
    if not ObjectId.is_valid(category_id):
        raise HTTPException(status_code=400, detail="Invalid category ID")
    category = await collection.find_one({"_id": ObjectId(category_id)})
    if not category:
        raise HTTPException(status_code=404, detail="category not found")
    data['updated_at'] = datetime.now(timezone.utc)
    result = await collection.update_one(
        {"_id": ObjectId(category_id)},
        {"$set": data}
    )
    return await get_category_by_id(category_id, db) if result.modified_count else None