from bson import ObjectId
from fastapi import HTTPException
from datetime import datetime, timezone
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.models.db.review_model import Review
from app.models.pydantic.base_model import User, User2
from app.models.pydantic.review_pydantic import (ReviewCreate, 
                                                 CreateReviewResponse, 
                                                 GetReviewsResponse, 
                                                 GetReviewByIDResponse)


# get a list of reviews
async def get_reviews(db : AsyncIOMotorDatabase,  limit : int = 20, offset : int = 0, rating : int = None, 
                      order_by : str = None):
    collection = db['reviews']
    if(order_by not in ['newest', 'highest_rated']):
        raise HTTPException(status_code=400, detail='Invalid order_by criteria')
    if rating and order_by == 'newest':
        cursor = collection.find({"rating": rating}).sort([("updated_at", -1), ("created_at", -1)]).skip(offset).limit(limit)
    elif rating and order_by == 'highest_rated':
        cursor = collection.find({"rating": rating}).sort([("rating", -1),('created_at', -1)]).skip(offset).limit(limit)
    elif not rating and order_by == 'newest':
        cursor = collection.find().sort([("updated_at", -1), ("created_at", -1)]).skip(offset).limit(limit)
    elif not rating and order_by == 'highest_rated':
        cursor = collection.find().sort([("rating", -1),('created_at', -1)]).skip(offset).limit(limit)
    else:
        cursor = collection.find().skip(offset).limit(limit)
    results = [cat async for cat in cursor]
    updated_results = []
    for review in results:
        user = await db['users'].find_one({'_id' : ObjectId(review['user_id'])})
        user['id'] = str(user['_id'])
        review['id'] = str(review['_id'])
        updated_results.append(CreateReviewResponse(**review, user = User(**user)))
    count = len(results)
    return GetReviewsResponse(count = count, results = updated_results)

# create a new review
async def create_review(book_id : str, user_id : str, review : ReviewCreate, db : AsyncIOMotorDatabase):
    collection = db['reviews']
    data = {
        'book_id' : book_id,
        'user_id' : user_id,
        'rating' : review.rating,
        'title' : review.title,
        'comment' : review.comment
    }
    data = Review(**data)
    result = await collection.insert_one(data.model_dump())
    data = data.model_dump()
    await db['users'].update_one({"_id": ObjectId(user_id)}, {"$inc": {"review_count": 1}})
    total_rating = 0
    count = 0
    cursor = collection.find({'book_id' : book_id})
    async for review in cursor:
        total_rating += review['rating']
        count += 1
    avg_rating = total_rating / count if count > 0 else 0
    await db['books'].update_one(
    {'_id': ObjectId(book_id)},
    {'$set': {'average_rating': avg_rating}})
    data['id'] = str(result.inserted_id)
    user = await db['users'].find_one({'_id' : ObjectId(user_id)})
    user['id'] = str(user['_id'])
    return CreateReviewResponse(**data, user = user)

# retreive a review by id
async def get_review_by_id(review_id: str, db : AsyncIOMotorDatabase):
    collection = db["reviews"]
    if not ObjectId.is_valid(review_id):
        raise HTTPException(status_code=400, detail="Invalid review ID")
    review_data = await collection.find_one({"_id": ObjectId(review_id)})
    if not review_data:
        raise HTTPException(status_code=404, detail="review not found")
    review = await collection.find_one({"_id": ObjectId(review_id)})
    user = await db['users'].find_one({'_id' : ObjectId(review['user_id'])})
    user['id'] = str(user['_id'])
    review['id'] = str(review['_id'])
    return GetReviewByIDResponse(**review, user = User2(**user)) if review else None

# Update an existing review
async def update_review(review_id: str, data: dict, db : AsyncIOMotorDatabase):
    collection = db["reviews"]
    if not ObjectId.is_valid(review_id):
        raise HTTPException(status_code=400, detail="Invalid review ID")
    review_data = await collection.find_one({"_id": ObjectId(review_id)})
    if not review_data:
        raise HTTPException(status_code=404, detail="review not found")
    
    data['updated_at'] = datetime.now(timezone.utc)
    result = await collection.update_one(
        {"_id": ObjectId(review_id)},
        {"$set": data}
    )
    review = await collection.find_one({"_id": ObjectId(review_id)})

    total_rating = 0
    count = 0
    cursor = collection.find({'book_id' : review['book_id']})
    async for review in cursor:
        total_rating += review['rating']
        count += 1
    avg_rating = total_rating / count if count > 0 else 0
    await db['books'].update_one(
    {'_id': ObjectId(review['book_id'])},
    {'$set': {'average_rating': avg_rating}})

    user = await db['users'].find_one({'_id' : ObjectId(review['user_id'])})
    review['id'] = str(review['_id'])
    user['id'] = str(user['_id'])
    return CreateReviewResponse(**review, user = User(**user)) if result.modified_count else None