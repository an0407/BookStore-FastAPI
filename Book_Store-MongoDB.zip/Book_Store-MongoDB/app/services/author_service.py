from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase
from datetime import datetime, timezone
from fastapi import HTTPException, status

from app.models.db.author_model import Author
from app.models.pydantic.author_pydantic import GetAuthorsResponse, GetAuthorIdResponse
from app.models.pydantic.base_model import Books

# Retrieve a list of Authors
async def get_authors(db : AsyncIOMotorDatabase, limit: int = 20, offset: int = 0, search : str = None):
    collection = db["authors"]
    if search:
        cursor = collection.find({"name": {"$regex": search,"$options": "i"}}).skip(offset).limit(limit)
    else:
        cursor = collection.find().skip(offset).limit(limit)
    results = [cat async for cat in cursor]
    for cat in results:
        cat['id'] = str(cat['_id'])
        del cat['_id']
    count = len(results)
    return GetAuthorsResponse(count = count, results = results)

# retreive a specific author by author_id
async def get_author_by_id(author_id: str, db : AsyncIOMotorDatabase):
    collection = db["authors"]
    if not ObjectId.is_valid(author_id):
        raise HTTPException(status_code=400, detail="Invalid author ID")
    author = await collection.find_one({"_id": ObjectId(author_id)})
    if not author:
        raise HTTPException(status_code=404, detail="author not found")
    author['id'] = str(author['_id'])
    books = db['books'].find({'author_id' : author_id})
    books_by_author = []
    async for book in books:
        book['id'] = str(book['_id'])
        books_by_author.append(Books(**book))
    return GetAuthorIdResponse(**author, books = books_by_author)

# create an author
async def create_author(data : dict, db = AsyncIOMotorDatabase):
    collection = db["authors"]
    if(await collection.find_one({"name": {"$regex": f"^{data['name']}$", "$options": "i"}})):
        raise HTTPException(status_code=400, detail="author already exists")
    data = Author(**data)
    result = await collection.insert_one(data.model_dump())
    data = data.model_dump()
    data['id'] = str(result.inserted_id)
    return data

# Update an existing author
async def update_author(author_id: str, data: dict, db : AsyncIOMotorDatabase):
    collection = db["authors"]
    if not ObjectId.is_valid(author_id):
        raise HTTPException(status_code=400, detail="Invalid author ID")
    author = await collection.find_one({"_id": ObjectId(author_id)})
    if not author:
        raise HTTPException(status_code=404, detail="author not found")
    data['updated_at'] = datetime.now(timezone.utc)
    result = await collection.update_one(
        {"_id": ObjectId(author_id)},
        {"$set": data}
    )
    data = await collection.find_one({'_id' : ObjectId(author_id)})
    data['id'] = author_id
    del data['_id']
    return data if result.modified_count else None