from fastapi import APIRouter, Depends, Query, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.database import get_database
from app.models.pydantic.author_pydantic import AuthorCreate, AuthorUpdate, AuthorCreateResponse, AuthorUpdateResponse, GetAuthorIdResponse, GetAuthorsResponse
# from app.models.db.author_model import Author as Aut
from app.services import author_service

router = APIRouter(prefix='/authors', tags = ['authors'])

# Retrieve a list of authors
@router.get("/", response_model=GetAuthorsResponse)
async def list_authors(db: AsyncIOMotorDatabase = Depends(get_database), limit: int = Query(20), offset: int = Query(0), search : str = Query(None)):
    return await author_service.get_authors(db, limit, offset, search)

# create a new author
@router.post('/', response_model= AuthorCreateResponse)
async def create_author(author : AuthorCreate, db : AsyncIOMotorDatabase = Depends(get_database)):
    return await author_service.create_author(author.model_dump(), db)

# Retrieve details of a specific author by id
@router.get("/{category_id}", response_model= GetAuthorIdResponse)
async def get_author(author_id: str, db: AsyncIOMotorDatabase = Depends(get_database)):
    try:
        return await author_service.get_author_by_id(author_id, db)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

# Update an existing author
@router.put("/{author_id}", response_model=AuthorUpdateResponse)
async def update_author(author_id: str, update_data: AuthorUpdate, db: AsyncIOMotorDatabase = Depends(get_database)):
    try:
        return await author_service.update_author(author_id, update_data.model_dump(exclude_unset=True), db)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))