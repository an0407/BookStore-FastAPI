from fastapi import APIRouter, Depends, Query, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase
# from typing import List
from app.database import get_database
from app.services import book_service
from app.models.pydantic.book_pydantic import BookCreate, BookUpdate, Book as Bk, BookCreateResponse, GetBooksResponse
from app.models.db.book_model import Book

router = APIRouter(prefix = '/books', tags=['books'])

# Retrieve a list of books
@router.get("/", response_model=GetBooksResponse)
async def list_books(db: AsyncIOMotorDatabase = Depends(get_database), limit: int = Query(20), offset: int = Query(0), 
                       author_id : str = Query(None), category_ids : str = Query(None)):
    return await book_service.get_books(db, limit, offset, author_id, category_ids)

# create a new book
@router.post('/', response_model= BookCreateResponse)
async def create_book(book : BookCreate, db : AsyncIOMotorDatabase = Depends(get_database)):
    return await book_service.create_book(book.model_dump(), db)

# Retrieve details of a specific book by id
@router.get("/{book_id}", response_model= BookCreateResponse)
async def get_book(book: str, db: AsyncIOMotorDatabase = Depends(get_database)):
    try:
        return await book_service.get_book_by_id(book, db)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

# Update an existing book
@router.put("/{author_id}", response_model=BookCreateResponse)
async def update_book(book_id: str, update_data: BookUpdate, db: AsyncIOMotorDatabase = Depends(get_database)):
    try:
        return await book_service.update_book(
            book_id, update_data.model_dump(exclude_unset=True), db
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))