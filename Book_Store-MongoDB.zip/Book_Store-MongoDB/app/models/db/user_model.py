from pydantic import Field
from app.models.db.base_model import create_update

class User(create_update):
    username : str = Field(...)
    email : str = Field(...)
    password : str = Field(...)
    first_name : str = Field(...)
    last_name : str = Field(...)
    review_count : int = Field(0)
