from pydantic import Field
from typing import List
from app.models.db.base_model import title_schema

class Book(title_schema):
    isbn : str
    publication_date: str = Field(...)  
    description: str = Field(...)
    page_count: int =Field(...)
    language: str = Field(...)
    author_id: str = Field(...)
    category_ids: List[str] = Field(...)
    average_rating : float = Field(0)
