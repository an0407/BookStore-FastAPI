from pydantic import Field
from app.models.db.base_model import name_schema

class Category(name_schema):
    description : str = Field(...)
    book_count : int = Field(0)

# def category_helper(category) -> dict:
#     return {
#         "id": str(category["_id"]),
#         "name": category["name"],
#         "description": category["description"],
#         "book_count": category.get("book_count", 0),
#         "created_at": category["created_at"],
#         "updated_at": category.get("updated_at")
#     }