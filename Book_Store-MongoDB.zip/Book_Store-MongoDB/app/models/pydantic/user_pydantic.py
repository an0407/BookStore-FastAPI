from pydantic import BaseModel, Field
from datetime import datetime, timezone
from typing import Optional, List
from app.models.pydantic.base_model import create, IdName

class User(BaseModel):
    username : str = Field(...)
    email : str = Field(...)
    password : str = Field(...)
    first_name : str = Field(...)
    last_name : str = Field(...)
    created_at : datetime = Field(default_factory=datetime.now(timezone.utc))
    updated_at : Optional[datetime] = None
    review_count : int = Field(0)

class UserCreate(BaseModel):
    username : str = Field(..., examples=['booklover'])
    email : str = Field(..., examples=['jonah@example.com'])
    password : str = Field(..., examples=['password123'])
    first_name : str = Field(..., examples=['John'])
    last_name : str = Field(..., examples=['Smith','Carey'])

class UserCreateResponse(create):
    username : str = Field(...)
    email : str = Field(...)
    first_name : str = Field(...)
    last_name : str = Field(...)
    review_count : int


class UserUpdate(BaseModel):
    username : str = Field(..., examples=['booklover'])
    email : str = Field(..., examples=['jonah@example.com'])
    password : str = Field(..., examples=['password123'])
    first_name : str = Field(..., examples=['John'])
    last_name : str = Field(..., examples=['Smith','Carey'])

class Review(BaseModel):
    id : str
    book : IdName
    rating : float
    created_at : datetime

class GetUserByIdResponse(BaseModel):
    id : str
    username : str = Field(...)
    email : str = Field(...)
    first_name : str = Field(...)
    last_name : str = Field(...)
    created_at : datetime = Field(default_factory=datetime.now(timezone.utc))
    updated_at : Optional[datetime] = None
    review_count : int
    recent_reviews : List[Review]

class GetUsersResponse(BaseModel):
    count : int
    next : Optional[str] = None
    previous : Optional[str] = None
    results : List[UserCreateResponse]
